import React, { useState } from "react";
import ServiciosPage from "./ServiciosPage.jsx";
import CrearCitaPage from "./CrearCitaPage.jsx";
import CitasPage from "./CitasPage.jsx";
import CrearServicioPage from "./CrearServicioPage.jsx";
import "bootstrap/dist/css/bootstrap.min.css";

const TABS = {
  SERVICIOS: "servicios",
  CREAR_CITA: "crear_cita",
  CITAS: "citas",
  CREAR_SERVICIO: "crear_servicio",
};

export default function App() {
  const [tab, setTab] = useState(TABS.SERVICIOS);

  return (
    <div className="container py-4">

      {/* Título principal */}
      <header className="text-center mb-4">
        <h1 className="fw-bold">CanaryCode Appointments</h1>
      </header>

      {/* Navegación tipo pestañas */}
      <nav className="nav nav-pills justify-content-center mb-4 gap-2">

        <button
          className={`btn ${
            tab === TABS.SERVICIOS ? "btn-primary text-white" : "btn-outline-primary"
          }`}
          onClick={() => setTab(TABS.SERVICIOS)}
        >
          Servicios
        </button>

        <button
          className={`btn ${
            tab === TABS.CREAR_CITA ? "btn-primary text-white" : "btn-outline-primary"
          }`}
          onClick={() => setTab(TABS.CREAR_CITA)}
        >
          Crear cita
        </button>

        <button
          className={`btn ${
            tab === TABS.CITAS ? "btn-primary text-white" : "btn-outline-primary"
          }`}
          onClick={() => setTab(TABS.CITAS)}
        >
          Ver citas
        </button>

        <button
          className={`btn ${
            tab === TABS.CREAR_SERVICIO ? "btn-primary text-white" : "btn-outline-primary"
          }`}
          onClick={() => setTab(TABS.CREAR_SERVICIO)}
        >
          Crear servicio
        </button>

      </nav>

      {/* TÍTULO DINÁMICO SEGÚN LA PESTAÑA */}
      <h2 className="text-center mb-3 fw-bold">
        {tab === TABS.SERVICIOS && "Servicios"}
        {tab === TABS.CREAR_CITA && "Crear cita"}
        {tab === TABS.CITAS && "Ver citas"}
        {tab === TABS.CREAR_SERVICIO && "Crear servicio"}
      </h2>

      {/* Contenido */}
      <main className="card shadow p-4">
        {tab === TABS.SERVICIOS && <ServiciosPage />}
        {tab === TABS.CREAR_CITA && <CrearCitaPage />}
        {tab === TABS.CITAS && <CitasPage />}
        {tab === TABS.CREAR_SERVICIO && <CrearServicioPage />}
      </main>

      {/* Footer */}
      <footer className="text-center text-muted mt-4">
        Consejo: primero crea 2–3 servicios en “Crear servicio”, luego crea una cita.
      </footer>

    </div>
  );
}
